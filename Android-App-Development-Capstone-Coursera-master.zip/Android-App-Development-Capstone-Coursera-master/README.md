# NewYork Times Popular Articles
***Key Features***
 - This projects aim at getting the latest articles from Newyork times newspaper and display them as a list. 
 - The user will be able to select any of the article and further read that article in a separate view.
 - User can also save them as favourite for later reading.
 - The app will remind him in some via a notification that he can read the article that he saved.

***Software Components***
 - Activity
 - Fragments
 - Content Providers
 - Broadcast Receivers
 - Service

***URL***
 - http://api.nytimes.com/svc/mostpopular/v2/mostviewed/all-sections/7.json?api-key=cd2506cf35504016a7579eea094ad1bd